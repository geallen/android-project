package tr.edu.iyte.todoapplicationwithmenus;

import android.app.Activity;

/**
 * Created by gamze on 06.12.2015.
 */
public class NewTodoActivity extends Activity {


}
